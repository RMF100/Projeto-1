<?php
// Define que a resposta será em formato JSON (para o JavaScript ler)
header('Content-Type: application/json; charset=utf-8');

// Verifica se o pedido foi feito via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1. Recolher e Limpar os Dados (Sanitização)
    $problem = isset($_POST['problem']) ? strip_tags(trim($_POST['problem'])) : 'Não especificado';
    $nome    = isset($_POST['nome']) ? strip_tags(trim($_POST['nome'])) : '';
    $email   = isset($_POST['email']) ? filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL) : '';
    $telefone= isset($_POST['telefone']) ? strip_tags(trim($_POST['telefone'])) : '';

    // 2. Validação Básica no Servidor
    if (empty($nome) || empty($email) || empty($telefone)) {
        echo json_encode(["success" => false, "message" => "Por favor preencha todos os campos obrigatórios."]);
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["success" => false, "message" => "Formato de email inválido."]);
        exit;
    }

    // 3. Configuração do Email
    // ---------------------------------------------------------
    // SUBSTITUI ISTO PELO TEU EMAIL REAL
    $to = "matosrmf@gmail.com"; 
    // ---------------------------------------------------------

    $subject = "Nova Marcação de Consulta: $nome";

    // Corpo do Email (HTML)
    $email_content = "
    <html>
    <head>
      <title>Novo Pedido de Agendamento</title>
    </head>
    <body>
      <h2>Detalhes do Pedido</h2>
      <p><strong>Motivo da Visita:</strong> $problem</p>
      <hr>
      <h3>Dados do Paciente</h3>
      <p><strong>Nome:</strong> $nome</p>
      <p><strong>Email:</strong> $email</p>
      <p><strong>Telefone:</strong> $telefone</p>
      <hr>
      <p><small>Enviado através do site Porto Dental Institute.</small></p>
    </body>
    </html>
    ";

    // Cabeçalhos do Email
    // O 'From' deve ser idealmente um email do próprio domínio do site para evitar spam
    $headers  = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
    $headers .= "From: no-reply@portodental.pt" . "\r\n";
    $headers .= "Reply-To: $email" . "\r\n";

    // 4. Enviar o Email
    if (mail($to, $subject, $email_content, $headers)) {
        echo json_encode(["success" => true]);
    } else {
        // Erro de servidor ao tentar enviar
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Erro ao enviar email. Tente novamente mais tarde."]);
    }

} else {
    // Acesso proibido (não é POST)
    http_response_code(403);
    echo json_encode(["success" => false, "message" => "Acesso proibido."]);
}
?>