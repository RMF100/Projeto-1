document.addEventListener("DOMContentLoaded", () => {
    
    /* ============================================================
       1. LÓGICA DE ANIMAÇÃO (Scroll Reveal)
       Funciona na Homepage e em qualquer elemento com a classe .reveal
    ============================================================ */
    const reveals = document.querySelectorAll(".reveal");

    if (reveals.length > 0) {
        const revealObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Adiciona a classe e altera estilos inline para garantir a animação
                    entry.target.classList.add("active");
                    entry.target.style.opacity = "1";
                    entry.target.style.transform = "translateY(0)";
                    
                    // Para de observar o elemento depois de animar
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1, // Dispara quando 10% do elemento é visível
            rootMargin: "0px 0px -50px 0px"
        });

        // Configuração inicial dos elementos
        reveals.forEach(el => {
            el.style.opacity = "0";
            el.style.transform = "translateY(30px)";
            el.style.transition = "all 1s ease-out";
            revealObserver.observe(el);
        });
    }

    /* ============================================================
       2. LÓGICA DO FORMULÁRIO MULTI-STEP
       Só corre se o formulário existir na página atual
    ============================================================ */
    const formElement = document.getElementById("multiStepForm");
    
    if (formElement) {
        // Inicializa a primeira aba
        showTab(currentTab);
    }
});

// --- Variáveis Globais do Formulário ---
let currentTab = 0;

function showTab(n) {
    const tabs = document.getElementsByClassName("tab");
    if (!tabs.length) return;

    tabs[n].style.display = "block";

    // Controle dos botões
    const prevBtn = document.getElementById("prevBtn");
    const nextBtn = document.getElementById("nextBtn");

    if (n === 0) {
        if(prevBtn) prevBtn.style.display = "none";
    } else {
        if(prevBtn) prevBtn.style.display = "inline-block";
    }

    if (n === (tabs.length - 1)) {
        if(nextBtn) nextBtn.innerHTML = "Confirmar Marcação";
    } else {
        if(nextBtn) nextBtn.innerHTML = "Continuar";
    }
}

function nextPrev(n) {
    const tabs = document.getElementsByClassName("tab");
    
    // Se for para avançar, valida o formulário
    if (n === 1 && !validateForm()) return false;

    // Esconde a aba atual
    tabs[currentTab].style.display = "none";
    
    // Incrementa o passo
    currentTab = currentTab + n;

    // Se chegou ao fim
    if (currentTab >= tabs.length) {
        submitForm();
        return false;
    }
    
    showTab(currentTab);
}

function validateForm() {
    const tabs = document.getElementsByClassName("tab");
    const currentTabElem = tabs[currentTab];
    let isValid = true;
    const inputs = currentTabElem.querySelectorAll("input[required]");
    const feedback = document.getElementById("feedbackMessage");

    // Validação Passo 1 (Cartões de Opção)
    if (currentTab === 0) {
        const selected = currentTabElem.querySelector(".option-card.selected");
        if (!selected) isValid = false;
    } 
    // Validação Outros Passos (Inputs de texto)
    else {
        inputs.forEach(input => {
            if (input.value.trim() === "") {
                input.style.borderColor = "#ef4444"; // Vermelho erro
                isValid = false;
            } else {
                input.style.borderColor = "rgba(255,255,255,0.1)"; // Normal
            }
        });
    }

    if (!isValid) {
        if(feedback) {
            feedback.innerText = "Por favor preencha os campos obrigatórios.";
            feedback.style.color = "#ef4444";
        }
    } else {
        if(feedback) feedback.innerText = "";
    }
    
    return isValid;
}

// Função auxiliar para selecionar os cartões (Passo 1)
function selectOption(card) {
    const container = card.parentElement;
    const cards = container.querySelectorAll(".option-card");
    
    // Remove seleção dos outros
    cards.forEach(c => {
        c.classList.remove("selected");
        const radio = c.querySelector("input");
        if(radio) radio.checked = false;
    });
    
    // Seleciona o atual
    card.classList.add("selected");
    const radio = card.querySelector("input");
    if(radio) radio.checked = true;
    
    // Limpa erro visual
    const feedback = document.getElementById("feedbackMessage");
    if(feedback) feedback.innerText = "";
}

// Simulação de Envio
// Função para Enviar o Formulário via PHP
function submitForm() {
    const form = document.getElementById("multiStepForm");
    const feedback = document.getElementById("feedbackMessage");
    const nextBtn = document.getElementById("nextBtn");
    const prevBtn = document.getElementById("prevBtn");

    // 1. Feedback visual de carregamento
    nextBtn.innerHTML = "A enviar...";
    nextBtn.disabled = true;
    if(prevBtn) prevBtn.style.display = "none"; // Esconde botão voltar

    // 2. Preparar dados
    const formData = new FormData(form);

    // 3. Enviar para o PHP (AJAX)
    fetch('send_mail.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // SUCESSO: Mostra a mensagem final
            const formCard = document.querySelector(".form-card");
            if(formCard) {
                formCard.innerHTML = `
                    <div style="text-align:center; padding:30px; animation: fadeIn 0.5s;">
                        <h2 style="color:#10b981; margin-bottom:15px; font-family:'Montserrat', sans-serif;">Pedido Enviado!</h2>
                        <p style="color:#94a3b8; margin-bottom:20px;">Recebemos os seus dados. A nossa equipa entrará em contacto brevemente.</p>
                        <a href="index.html" class="btn-primary" style="display:inline-block; text-decoration:none; padding:10px 20px; color:white;">Voltar ao Início</a>
                    </div>
                `;
            }
        } else {
            // ERRO (Validação PHP ou Falha de envio)
            throw new Error(data.message || "Ocorreu um erro desconhecido.");
        }
    })
    .catch(error => {
        // Trata erros de rede ou do PHP
        console.error('Erro:', error);
        feedback.innerText = error.message || "Erro ao conectar ao servidor.";
        feedback.style.color = "#ef4444";
        
        // Restaura os botões
        nextBtn.innerHTML = "Tentar Novamente";
        nextBtn.disabled = false;
        if(prevBtn) prevBtn.style.display = "inline-block";
    });
}